package br.com.fiap.view;

import java.rmi.RemoteException;

import br.com.fiap.bo.NotaBOStub;
import br.com.fiap.bo.NotaBOStub.CalcularMedia;
import br.com.fiap.bo.NotaBOStub.CalcularMediaResponse;

public class MediaView {

	public static void main(String[] args) {
		
		try {
			NotaBOStub stub = new NotaBOStub();
			//Valores para enviar para o web service
			CalcularMedia parametros = new CalcularMedia();
			parametros.setAm(8);
			parametros.setNac(10);
			parametros.setPs(4);
			
			//Chama o ws e recupera o retorno
			CalcularMediaResponse resp =
							stub.calcularMedia(parametros);
			
			//Exibe a resposta do ws
			System.out.println(resp.get_return());
			
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
	}
	
}