package br.com.fiap.view;

import java.rmi.RemoteException;
import java.util.Scanner;

import org.apache.axis2.AxisFault;

import br.com.fiap.bo.NotaBOStub;
import br.com.fiap.bo.NotaBOStub.CalcularPs;
import br.com.fiap.bo.NotaBOStub.CalcularPsResponse;

public class PsView {

	public static void main(String[] args) {
		//Chamar o ws para calcular a nota de ps necess�ria
		Scanner sc = new Scanner(System.in);
		
		try {
			NotaBOStub stub = new NotaBOStub();
			
			CalcularPs params = new CalcularPs();
			System.out.print("Digite a m�dia de nac: ");
			params.setNac(sc.nextFloat());
			System.out.print("Digite a nota de am: ");
			params.setAm(sc.nextFloat());
			
			CalcularPsResponse resp = stub.calcularPs(params);
			
			System.out.println("Voc� precisa de : " + 
											resp.get_return());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		sc.close();
	}
	
}