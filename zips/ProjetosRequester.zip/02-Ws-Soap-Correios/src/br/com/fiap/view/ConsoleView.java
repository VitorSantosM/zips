package br.com.fiap.view;

import java.rmi.RemoteException;
import java.util.Scanner;

import org.tempuri.CalcPrecoPrazoWSStub;
import org.tempuri.CalcPrecoPrazoWSStub.CServico;
import org.tempuri.CalcPrecoPrazoWSStub.CalcPrazo;
import org.tempuri.CalcPrecoPrazoWSStub.CalcPrazoResponse;

public class ConsoleView {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		//Calcular o prazo
		
		try {
			CalcPrecoPrazoWSStub stub = new CalcPrecoPrazoWSStub();
			
			//40010 Servi�o
			CalcPrazo params = new CalcPrazo();
			params.setNCdServico("40010");
			System.out.print("CEP de origem: ");
			params.setSCepOrigem(sc.next()+sc.nextLine());
			System.out.print("CEP de destino: ");
			params.setSCepDestino(sc.next()+sc.nextLine());
			
			CalcPrazoResponse resp = stub.calcPrazo(params);
			
			CServico servico = resp.getCalcPrazoResult()
					.getServicos().getCServico()[0];
			
			System.out.println("Prazo: " + servico.getPrazoEntrega());
			System.out.println("Data M�xima: " + servico.getDataMaxEntrega());
		} catch (RemoteException e) {
			e.printStackTrace();
		}
		
		sc.close();
	}
	
}
